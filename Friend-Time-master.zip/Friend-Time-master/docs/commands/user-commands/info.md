---
description: More information about Friend Time.
---

# info

## Summary

The `/info` command shows more information about Friend Time.

## Show Information about Friend Time

Type `/info` to show information about Friend Time.

![](../../.gitbook/assets/image%20%2822%29.png)



