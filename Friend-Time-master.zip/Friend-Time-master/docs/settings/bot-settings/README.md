---
description: Settings for bots.
---

# Bot Settings

## _**Coming Soon**_

