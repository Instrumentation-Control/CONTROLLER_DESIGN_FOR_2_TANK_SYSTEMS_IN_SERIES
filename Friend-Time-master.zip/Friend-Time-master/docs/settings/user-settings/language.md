# Language

## Description

The user **Language** setting changes Friend Time's language for the user.

Type `/translate` to see what languages are available.

![](../../.gitbook/assets/image%20%2863%29.png)

{% hint style="info" %}
 If you are interested in providing a translation, please contact the staff in our [support server](https://discord.gg/GQcBR8e).
{% endhint %}

{% hint style="info" %}
To learn how to change settings like this one, see the [me command](../../commands/user-commands/me.md).
{% endhint %}

