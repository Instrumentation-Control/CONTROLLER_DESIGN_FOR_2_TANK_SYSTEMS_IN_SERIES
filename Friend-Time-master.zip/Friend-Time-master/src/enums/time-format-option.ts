export enum TimeFormatOption {
    TWELVE_HOUR = 'TWELVE_HOUR',
    TWENTY_FOUR_HOUR = 'TWENTY_FOUR_HOUR',
}
