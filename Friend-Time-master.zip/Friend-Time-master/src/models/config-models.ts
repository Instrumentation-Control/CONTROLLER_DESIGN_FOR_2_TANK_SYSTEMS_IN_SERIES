export interface BotSite {
    name: string;
    enabled: boolean;
    url: string;
    authorization: string;
    body: string;
}
